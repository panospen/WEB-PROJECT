<?php 
 
 $con = mysqli_connect("localhost","root", "", "xristos") or die("Couldn't connect");

?>